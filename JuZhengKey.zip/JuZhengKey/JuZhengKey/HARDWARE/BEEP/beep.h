#ifndef __BEEP_H
#define __BEEP_H	 
#include "sys.h"

#define BEEP PBout(8)			   

void BEEP_Init(void);	
		 				    
#endif

