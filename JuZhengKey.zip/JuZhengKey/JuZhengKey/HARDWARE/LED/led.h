#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED_RED PBout(0)
#define LED_GREEN PBout(1)
#define LED_BLUE PBout(2)	

void LED_Init(void);

		 				    
#endif
